#ifndef BSW_ETC_ETC_H_
#define BSW_ETC_ETC_H_

void delay_ms(unsigned int delay_time);

#endif /* BSW_ETC_ETC_H_ */
