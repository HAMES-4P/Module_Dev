/*
 * AppScheduling.h
 *
 *  Created on: 2023. 11. 26.
 *      Author: 현대오토9
 */

#ifndef LIBRARIES_BSW_APPSCHEDULER_APPSCHEDULING_H_
#define LIBRARIES_BSW_APPSCHEDULER_APPSCHEDULING_H_

#include "Ifx_Types.h"

extern void AppScheduling();

#endif /* LIBRARIES_BSW_APPSCHEDULER_APPSCHEDULING_H_ */
